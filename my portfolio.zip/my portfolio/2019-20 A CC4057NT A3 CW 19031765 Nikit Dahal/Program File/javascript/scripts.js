function validate(){
  var fname = document.forms["messageform"]["firstname"].value;
  var lname = document.forms["messageform"]["lastname"].value;
  var phone = document.forms["messageform"]["phone"].value;
  var email = document.forms["messageform"]["email"].value;
  var message = document.forms["messageform"]["message"].value;

  if (fname=="" || lname=="" || phone=="" || email=="" || message=="") {
    alert("You havent fill the required section.");
  }
  else{
    alert("thanks for feedback");
  }
  }